// --- BASE DE DONNÉES INITIALE ---
const medicamentsInitiaux = [
    { code: "ART001", nom: "Vasocart th 500mg", quantite: 120, unite: "Boîte", dateEntree: "2026-04-10", dateExpiration: "2026-05-10" },
    { code: "ART002", nom: "Dr cold 1g", quantite: 15, unite: "Boîte", dateEntree: "2026-05-01", dateExpiration: "2026-06-15" },
    { code: "ART003", nom: "clamoxyl 5mg", quantite: 85, unite: "Boîte", dateEntree: "2026-03-15", dateExpiration: "2027-03-14" },
    { code: "ART004", nom: "Aspirine 75mg", quantite: 40, unite: "Boîte", dateEntree: "2026-02-10", dateExpiration: "2026-04-30" },
    { code: "ART005", nom: "Alfamox", quantite: 200, unite: "Flacon", dateEntree: "2026-05-12", dateExpiration: "2028-05-12" }
];

// Chargement des données à partir du localStorage ou application des valeurs par défaut
let listeStock = JSON.parse(localStorage.getItem('stockMedias')) || [...medicamentsInitiaux];
let registreEntrees = JSON.parse(localStorage.getItem('registreEntrees')) || [];
let registreSorties = JSON.parse(localStorage.getItem('registreSorties')) || [];
let journalHistorique = [{ temps: "14:00", action: "Initialisation globale des composants système terminée." }];

// Éléments pour la facturation en attente (bouton Ajout)
let panierFacturation = [];

// --- MODULE 1 : VERIFICATION DE LA CONNEXION ---
document.getElementById('login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const nomSaisi = document.getElementById('username').value;
    const motDePasseSaisi = document.getElementById('password').value;

    if (nomSaisi === "pharmacie" && motDePasseSaisi === "1234") {
        document.getElementById('login-interface').style.display = 'none';
        document.getElementById('main-interface').style.display = 'block';
        
        ajouterActionHistorique("Connexion de l'administrateur validée.");
        rafraichirTout();
    } else {
        alert("Échec d'authentification : Identifiants incorrects !");
    }
});

// --- MODULE 2 : NAVIGATION PRINCIPALE (ONGLETS) ---
const ongletsWeb = document.querySelectorAll('.web-link');
const ecransContenu = document.querySelectorAll('.screen-content');

ongletsWeb.forEach(onglet => {
    onglet.addEventListener('click', function() {
        ongletsWeb.forEach(o => o.classList.remove('active'));
        this.classList.add('active');
        
        const cibleScreen = this.getAttribute('data-screen');
        ecransContenu.forEach(ecran => {
            ecran.id === cibleScreen ? ecran.classList.add('active') : ecran.classList.remove('active');
        });
        ajouterActionHistorique(`Accès à l'onglet : ${this.innerText}`);
        
        if (cibleScreen === 'inventaire-screen') {
            afficherTableauStock();
            afficherTableauEntrees();
            afficherTableauSorties();
        } else if (cibleScreen === 'facturation-screen') {
            mettreAJourSelectMedicaments();
        }
    });
});

// --- MODULE 3 : NAVIGATION SECONDAIRE (SOUS-ONGLETS INVENTAIRE) ---
const sousOnglets = document.querySelectorAll('.sub-link');
const sousEcrans = document.querySelectorAll('.sub-screen-content');

sousOnglets.forEach(btn => {
    btn.addEventListener('click', function() {
        sousOnglets.forEach(b => b.classList.remove('active'));
        this.classList.add('active');

        const cibleSub = this.getAttribute('data-sub');
        sousEcrans.forEach(scr => {
            scr.id === cibleSub ? scr.classList.add('active') : scr.classList.remove('active');
        });
    });
});

// --- MODULE 4 : AFFICHAGE DES INVENTAIRES ---

// 4.1 Inventaire Actuel
function afficherTableauStock() {
    const tableBody = document.getElementById('stock-table-body');
    if (!tableBody) return;
    tableBody.innerHTML = "";

    listeStock.forEach((art, index) => {
        const row = document.createElement('tr');
        row.style.borderBottom = "1px solid #011107";
        row.innerHTML = `
          <td style="padding: 12px 10px; font-weight: bold; color: var(--gray-text);">${art.code}</td>
          <td style="padding: 12px 10px; font-weight: 600;">${art.nom}</td>
          <td style="padding: 12px 10px;">${art.quantite}</td>
          <td style="padding: 12px 10px;">${art.unite}</td>
          <td style="padding: 12px 10px;">${art.dateEntree}</td>
          <td style="padding: 12px 10px;">${art.dateExpiration}</td>
          <td style="padding: 12px 10px;">
           <button onclick="window.modifierQuantite(${index})" style="background-color: #2ecc71; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 11px; margin-right: 5px;">Modifier</button>
          </td>
          <td style="padding:12px 10px;">
           <button onclick="window.supprimerMedicament(${index})" style="background-color: #e74c3c; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; font-size: 11px;">Retirer</button>
          </td>
        `;
        tableBody.appendChild(row);
    });
}

// 4.2 Inventaire d'entrée
function afficherTableauEntrees() {
    const tableBody = document.getElementById('entree-table-body');
    if (!tableBody) return;
    tableBody.innerHTML = "";

    if (registreEntrees.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5" style="padding:15px; text-align:center; color:gray;">Aucune entrée enregistrée.</td></tr>`;
        return;
    }

    registreEntrees.forEach(item => {
        const row = document.createElement('tr');
        row.style.borderBottom = "1px solid #010c05";
        row.innerHTML = `
            <td style="padding: 12px 10px;">${item.horodatage}</td>
            <td style="padding: 12px 10px; font-weight:bold;">${item.code}</td>
            <td style="padding: 12px 10px;">${item.nom}</td>
            <td style="padding: 12px 10px; color:#27ae60; font-weight:bold;">+${item.quantite}</td>
            <td style="padding: 12px 10px;">${item.unite}</td>
        `;
        tableBody.appendChild(row);
    });
}

// 4.3 Inventaire de sortie
function afficherTableauSorties() {
    const tableBody = document.getElementById('sortie-table-body');
    if (!tableBody) return;
    tableBody.innerHTML = "";

    if (registreSorties.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5" style="padding:15px; text-align:center; color:gray;">Aucune sortie ou vente enregistrée.</td></tr>`;
        return;
    }

    registreSorties.forEach(item => {
        const row = document.createElement('tr');
        row.style.borderBottom = "1px solid #010904";
        row.innerHTML = `
            <td style="padding: 12px 10px;">${item.horodatage}</td>
            <td style="padding: 12px 10px; font-weight:600;">${item.nomMedicament}</td>
            <td style="padding: 12px 10px; color:#c0392b; font-weight:bold;">-${item.quantite}</td>
            <td style="padding: 12px 10px;">${item.nomClient}</td>
            <td style="padding: 12px 10px;">${item.telClient}</td>
        `;
        tableBody.appendChild(row);
    });
}


// --- MODULE 5 : TRAITEMENT DE L'AJOUT DE MARCHANDISE ---
document.getElementById('add-stock-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const nom = document.getElementById('prod-name').value;
    const quantite = parseInt(document.getElementById('prod-qty').value, 10);
    const unite = document.getElementById('prod-unit').value;
    const dateEntree = document.getElementById('prod-date-in').value;
    const dateExpiration = document.getElementById('prod-date-exp').value;
    
    const nouveauCode = "ART" + (listeStock.length + 1).toString().padStart(3, '0');
    
    const nouvelArticle = {
        code: nouveauCode, nom: nom, quantite: quantite, unite: unite, dateEntree: dateEntree, dateExpiration: dateExpiration
    };
    
    // Ajout au stock actuel
    listeStock.push(nouvelArticle);
    
    // Ajout automatique au registre d'entrée (Inventaire d'entrée)
    const maintenant = new Date();
    const horodatage = maintenant.toLocaleDateString() + " à " + maintenant.getHours().toString().padStart(2, '0') + ":" + maintenant.getMinutes().toString().padStart(2, '0');
    
    registreEntrees.unshift({
        horodatage: horodatage, code: nouveauCode, nom: nom, quantite: quantite, unite: unite
    });

    sauvegarderDonnees();
    rafraichirTout();
    
    ajouterActionHistorique(`Marchandise ajoutée : Lot d'entrée créé pour ${nom} (Qté: ${quantite}).`);
    this.reset();
    alert("Produit ajouté avec succès et consigné dans l'inventaire d'entrée !");
});


// --- MODULE 6 : ACTIONS DU STOCK ACTUEL (MODIFIER/SUPPRIMER) ---

window.modifierQuantite = function(index) {
    const articleCible = listeStock[index];
    if (!articleCible) return;

    let nouvelleQuantite = prompt(`Modifier la quantité pour "${articleCible.nom}" :`, articleCible.quantite);
    if (nouvelleQuantite !== null && nouvelleQuantite.trim() !== "") {
        let quantiteNombre = parseInt(nouvelleQuantite, 10);
        if (!isNaN(quantiteNombre) && quantiteNombre >= 0) {
            if (confirm(`Confirmez-vous le changement de quantité pour "${articleCible.nom}" de ${articleCible.quantite} vers ${quantiteNombre} ?`)) {
                ajouterActionHistorique(`Modification manuelle : ${articleCible.nom} (${articleCible.quantite} -> ${quantiteNombre})`);
                articleCible.quantite = quantiteNombre;
                sauvegarderDonnees();
                rafraichirTout();
            }
        } else {
            alert("Veuillez entrer une quantité numérique valide.");
        }
    }
};

window.supprimerMedicament = function(index) {
    const articleCible = listeStock[index];
    if (confirm(`Confirmez-vous le retrait complet de "${articleCible.nom}" ?`)) {
        ajouterActionHistorique(`Retrait produit : ${articleCible.nom} supprimé.`);
        listeStock.splice(index, 1);
        sauvegarderDonnees();
        rafraichirTout();
    }
};


// --- MODULE 7 : MODULE DE FACTURATION COMPLET ---

// Remplir le select dynamiquement en fonction du stock
function mettreAJourSelectMedicaments() {
    const select = document.getElementById('bill-prod-select');
    if (!select) return;
    select.innerHTML = '<option value="">-- Choisir un produit en stock --</option>';

    listeStock.forEach((art, index) => {
        if (art.quantite > 0) {
            const opt = document.createElement('option');
            opt.value = index;
            opt.textContent = `${art.nom} (Dispo: ${art.quantite} ${art.unite})`;
            select.appendChild(opt);
        }
    });
}

// Remplissage automatique de l'unité quand on choisit un médicament
document.getElementById('bill-prod-select').addEventListener('change', function() {
    const index = this.value;
    const unitInput = document.getElementById('bill-unit');
    if (index !== "") {
        unitInput.value = listeStock[index].unite;
    } else {
        unitInput.value = "";
    }
});

// Bouton 1 : AJOUT (Insérer un article dans le panier/aperçu temporaire)
document.getElementById('btn-bill-ajouter').addEventListener('click', function() {
    const select = document.getElementById('bill-prod-select');
    const index = select.value;
    const qty = parseInt(document.getElementById('bill-qty').value, 10);
    const dateVente = document.getElementById('bill-date').value;
    const clientNom = document.getElementById('bill-client-name').value;
    const clientTel = document.getElementById('bill-client-phone').value;

    if (index === "" || isNaN(qty) || qty <= 0 || !dateVente || !clientNom || !clientTel) {
        alert("Veuillez remplir tous les champs du formulaire avant d'ajouter.");
        return;
    }

    const produitEnStock = listeStock[index];

    // Vérifier la disponibilité en stock
    if (qty > produitEnStock.quantite) {
        alert(`Stock insuffisant ! Quantité maximale disponible : ${produitEnStock.quantite}`);
        return;
    }

    // Ajouter au panier temporaire de facturation
    panierFacturation.push({
        stockIndex: parseInt(index, 10),
        nomMedicament: produitEnStock.nom,
        quantite: qty,
        unite: produitEnStock.unite,
        dateVente: dateVente,
        nomClient: clientNom,
        telClient: clientTel
    });

    // Mettre à jour l'aperçu textuel
    const previewCard = document.getElementById('invoice-preview-card');
    const previewList = document.getElementById('bill-items-preview');
    previewCard.style.display = "block";
    
    const li = document.createElement('li');
    li.innerHTML = `<strong>${produitEnStock.nom}</strong> x${qty} ${produitEnStock.unite} - Client: ${clientNom} (${dateVente})`;
    previewList.appendChild(li);

    // Réinitialiser uniquement les champs du produit pour permettre d'autres ajouts si nécessaire
    select.value = "";
    document.getElementById('bill-qty').value = "";
    document.getElementById('bill-unit').value = "";
});

// Bouton 2 : ANNULATION (Vider le formulaire et le panier temporaire)
document.getElementById('btn-bill-annuler').addEventListener('click', function() {
    if (confirm("Annuler la saisie en cours et effacer la facture ?")) {
        document.getElementById('billing-form').reset();
        panierFacturation = [];
        document.getElementById('bill-items-preview').innerHTML = "";
        document.getElementById('invoice-preview-card').style.display = "none";
        ajouterActionHistorique("Session de facturation annulée par l'utilisateur.");
    }
});

// Bouton 3 : CONFIRMATION (Validation définitive, déduction du stock et écriture dans l'inventaire de sortie)
document.getElementById('billing-form').addEventListener('submit', function(e) {
    e.preventDefault(); // Intercepte la validation

    if (panierFacturation.length === 0) {
        alert("Votre panier de facturation est vide. Cliquez d'abord sur le bouton 'Ajout' pour ajouter des éléments.");
        return;
    }

    if (confirm(`Confirmez-vous la vente définitive de ces ${panierFacturation.length} élément(s) ?`)) {
        const maintenant = new Date();
        const horodatageSortie = maintenant.toLocaleDateString() + " à " + maintenant.getHours().toString().padStart(2, '0') + ":" + maintenant.getMinutes().toString().padStart(2, '0');

        // Appliquer toutes les transactions du panier
        panierFacturation.forEach(item => {
            const produit = listeStock[item.stockIndex];
            
            // Sécurité double vérification quantité
            if (produit && produit.quantite >= item.quantite) {
                // 1. Soustraction de la quantité globale du stock actuel
                produit.quantite -= item.quantite;

                // 2. Écriture dans le registre de l'inventaire de sortie
                registreSorties.unshift({
                    horodatage: horodatageSortie,
                    nomMedicament: item.nomMedicament,
                    quantite: item.quantite,
                    nomClient: item.nomClient,
                    telClient: item.telClient
                });

                ajouterActionHistorique(`Facturation validée : Sortie de ${item.nomMedicament} (x${item.quantite}) pour le client ${item.nomClient}.`);
            }
        });

        // Vider le panier et nettoyer l'interface
        panierFacturation = [];
        document.getElementById('bill-items-preview').innerHTML = "";
        document.getElementById('invoice-preview-card').style.display = "none";
        document.getElementById('billing-form').reset();

        sauvegarderDonnees();
        rafraichirTout();
        mettreAJourSelectMedicaments();

        alert("Facture confirmée ! Les stocks ont été mis à jour et consignés dans l'inventaire de sortie.");
    }
});


// --- MODULE 8 : ALERTES AUTOMATIQUES ---
function calculerAlertesPerissables() {
    const conteneurAlertes = document.getElementById('expiry-alerts-container');
    if (!conteneurAlertes) return;
    conteneurAlertes.innerHTML = ""; 
    
    const dateAujourdhui = new Date("2026-05-16");
    
    listeStock.forEach(article => {
        const dateExp = new Date(article.dateExpiration);
        const diffTemps = dateExp.getTime() - dateAujourdhui.getTime();
        const diffJours = Math.ceil(diffTemps / (1000 * 60 * 60 * 24));
        
        let alerteActive = false;
        let message = "";
        let statut = "";
        
        if (diffJours <= 0) {
            alerteActive = true; statut = "PÉRIMÉ";
            message = `Produit obsolète depuis le ${article.dateExpiration}. Extraction immédiate requise.`;
        } else if (diffJours <= 45) {
            alerteActive = true; statut = "CRITIQUE";
            message = `Seuil critique atteint. Rupture ou péremption imminente dans ${diffJours} jours.`;
        }
        
        if (alerteActive) {
            const carte = document.createElement('div');
            carte.className = "alert-item";
            carte.innerHTML = `
                <div class="alert-info">
                    <h4>${article.nom} (ID: ${article.code})</h4>
                    <p>Analyse système : <strong>${message}</strong> — Quantité disponible : ${article.quantite} ${article.unite}</p>
                </div>
                <span class="badge-expiry" style="background: ${statut === 'PÉRIMÉ' ? '#c0392b' : '#d35400'}">${statut}</span>
            `;
            conteneurAlertes.appendChild(carte);
        }
    });
}

// --- MODULE 9 : GESTION DE L'HISTORIQUE & UTILS ---
function ajouterActionHistorique(texteAction) {
    const maintenant = new Date();
    const heureFormatee = maintenant.getHours().toString().padStart(2, '0') + ":" + maintenant.getMinutes().toString().padStart(2, '0');
    journalHistorique.unshift({ temps: heureFormatee, action: texteAction });
    rafraichirAffichageHistorique();
}

function rafraichirAffichageHistorique() {
    const conteneur = document.getElementById('history-log-container');
    if (!conteneur) return;
    conteneur.innerHTML = "";
    journalHistorique.forEach(item => {
        const li = document.createElement('li');
        li.className = "history-item";
        li.innerHTML = `<span class="history-time">[${item.temps}]</span> <span>${item.action}</span>`;
        conteneur.appendChild(li);
    });
}

document.getElementById('clear-history-btn').addEventListener('click', function() {
    journalHistorique = [{ temps: "--:--", action: "Journal d'activité remis à zéro par l'opérateur." }];
    rafraichirAffichageHistorique();
});

function sauvegarderDonnees() {
    localStorage.setItem('stockMedias', JSON.stringify(listeStock));
    localStorage.setItem('registreEntrees', JSON.stringify(registreEntrees));
    localStorage.setItem('registreSorties', JSON.stringify(registreSorties));
}

function rafraichirTout() {
    afficherTableauStock();
    afficherTableauEntrees();
    afficherTableauSorties();
    calculerAlertesPerissables();
    rafraichirAffichageHistorique();
}

// Démarrage par défaut
rafraichirTout();
